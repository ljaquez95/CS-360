package com.example.wolfpax

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MainScreen(db: DatabaseHelper) {
    var itemName by remember { mutableStateOf("") }
    var itemQty by remember { mutableStateOf("") }
    var itemList by remember { mutableStateOf(db.getAllItems()) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(value = itemName, onValueChange = { itemName = it }, label = { Text("Item Name") })
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = itemQty, onValueChange = { itemQty = it }, label = { Text("Quantity") })
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            db.insertItem(itemName, itemQty.toIntOrNull() ?: 0)
            itemName = ""
            itemQty = ""
            itemList = db.getAllItems()
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Add Item")
        }
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(itemList) { item ->
                var newQty by remember { mutableStateOf(item.quantity.toString()) }
                Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                    Text(text = "${item.item} (ID: ${item.id})")
                    OutlinedTextField(
                        value = newQty,
                        onValueChange = { newQty = it },
                        label = { Text("Edit Quantity") }
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Button(onClick = {
                            db.updateItem(item.id, item.item, newQty.toIntOrNull() ?: item.quantity)
                            itemList = db.getAllItems()
                        }) {
                            Text("Update")
                        }
                        Button(onClick = {
                            db.deleteItem(item.id)
                            itemList = db.getAllItems()
                        }) {
                            Text("Delete")
                        }
                    }
                }
                Divider()
            }
        }
    }
}
