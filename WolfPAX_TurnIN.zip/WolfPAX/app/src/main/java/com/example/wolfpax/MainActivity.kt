package com.example.wolfpax

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.example.wolfpax.ui.theme.WolfPAXTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = DatabaseHelper(this)
        setContent {
            WolfPAXTheme {
                var isLoggedIn by remember { mutableStateOf(false) }
                if (isLoggedIn) {
                    MainScreen(db)
                } else {
                    LoginScreen(db) { success -> isLoggedIn = success }
                }
            }
        }
    }
}

