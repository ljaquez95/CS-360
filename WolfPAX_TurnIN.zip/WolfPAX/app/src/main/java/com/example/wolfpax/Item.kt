package com.example.wolfpax

data class Item(val id: Int, val item: String, val quantity: Int)
