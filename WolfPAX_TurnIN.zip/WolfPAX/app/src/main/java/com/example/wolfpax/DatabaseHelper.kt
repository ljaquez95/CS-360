package com.example.wolfpax

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "wolfpax.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)")
        db.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, item TEXT, quantity INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS inventory")
        onCreate(db)
    }

    fun registerUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("username", username)
        cv.put("password", password)
        return db.insert("users", null, cv) != -1L
    }

    fun loginUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", arrayOf(username, password))
        val result = cursor.count > 0
        cursor.close()
        return result
    }

    fun insertItem(item: String, qty: Int) {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("item", item)
        cv.put("quantity", qty)
        db.insert("inventory", null, cv)
    }

    fun getAllItems(): List<Item> {
        val list = mutableListOf<Item>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM inventory", null)
        while (cursor.moveToNext()) {
            list.add(Item(cursor.getInt(0), cursor.getString(1), cursor.getInt(2)))
        }
        cursor.close()
        return list
    }

    fun deleteItem(id: Int) {
        val db = writableDatabase
        db.delete("inventory", "id=?", arrayOf(id.toString()))
    }

    fun updateItem(id: Int, item: String, qty: Int) {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("item", item)
        cv.put("quantity", qty)
        db.update("inventory", cv, "id=?", arrayOf(id.toString()))
    }
}
